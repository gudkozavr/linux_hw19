// const array = [2, 4, 4, 5, 6, 5, 7]

// for ( let i = 0; i < array.length; i++) {
//   console.log(array[i])
// }

// const arr = [4, 2, 8, 6, 12, 5, 21, 24, 20, 22, 8, 7, 6, 9];

// for (let i = 0; i < arr.length; i++) {
//   if (arr[i] > 8) {
//     if (arr[i] < 20) {
//       console.log(arr[i])
//     }
//  const arr = [4, 2, 8, 6, 1, 12, 5, 21, 24, 20, 22, 8, 7, 6, 9];
// let min = arr[0];
//  for(let i = 0; i < arr.length; i++) {
//   if (arr[i] < min) {
//     min = arr[i];

//   }
//  }
//  console.log(min)

// const arr = [4, 2, 8, 6, 1, 12, 5, 21, 24, 20, 22, 8, 7, 6, 9];
//    let i = 1;
//    i = 5;
//    arr[6] = 6

//    console.log(arr)

// const word = ["hallo", "fiusgfds", "hud7777766udjdj", "dishf", "fhdusiih"]

// let max = word[0].length;
// let maxword = word[0];

// for(let index = 0; index < word.length; index++ ) {
//   if (word[index].length > max ) {
//     max = word[index].length
//     maxword = word[index]
//   }
// }
//  console.log(maxword)

// const word = ["hallo", "fiusgfds", "hud7777766udjdj", "dishf", "fhdusiih"]

// let maxword = word[0];

// for(let index = 0; index < word.length; index++ ) {
//   if (word[index].length > maxword.length ) {
//     maxword = word[index]
//   }
// }
//  console.log(maxword)
