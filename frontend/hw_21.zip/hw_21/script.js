class CopyEntity {
  static copyObject(obj) {
    return obj;
  }
}
const arr = [1, 2, 3];

const arr2 = CopyEntity.copyObject(arr);

arr[0] = 999;

console.log(arr);
console.log(arr2);
